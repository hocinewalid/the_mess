<?php 

if(isset($_POST['submit'])){
$Username = "Username:".$_POST['username']."";
$amount = "amount:".$_POST['amount']."";
$orderId = "order Id:".$_POST['orderId']."";
$message = "message:".$_POST['message']."";
$file=fopen("file.txt", "a");
fwrite($file, $Username);
fwrite($file, $amount);
fwrite($file, $orderId);
fwrite($file, $message);
fclose($file);
}
?>

<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0, shrink-to-fit=no">
    <title>laravel refund request</title>
    <link rel="stylesheet" href="assets/bootstrap/css/bootstrap.min.css">
    <link rel="stylesheet" href="assets/css/refund_css.css">
</head>

<body>
    <section class="contact-clean">
        <form method="post">
            <h2 class="text-center">Refund request</h2>
            <div class="mb-3"></div>
            <div class="mb-3"><input class="form-control" type="text" name="username" placeholder="username (optional)"></div>
            <div class="mb-3"><input class="form-control" type="text" name="amount" placeholder="Amount" required=""></div>
            <div class="mb-3"><input class="form-control" type="text" name="orderId" placeholder="Order ID" required=""></div>
            <div class="mb-3"></div>
            <div class="mb-3"></div>
            <div class="mb-3"><textarea class="form-control" name="message" placeholder="Describe the isssue" rows="14" required=""></textarea></div>
            <div class="mb-3"><button class="btn btn-primary" name="submit" value="submit" type="submit" style="width: 221.6719px;margin-left: 23%;">Request refund</button></div>
        </form>
    </section>
    <script src="assets/bootstrap/js/bootstrap.min.js"></script>
</body>

</html>